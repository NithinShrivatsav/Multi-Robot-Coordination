function [L] = updateGraph(poses, delta)   
    N = size(poses, 2);
    L = update_delta_disk(poses(1:2, 1:N), delta);
end