function[opponents] = find_opponents(L, agent)
    N = size(L, 2);
    if(agent > N/2)
        all_opps = [1:N/2];
    else
        all_opps = [(N/2)+1:N];
    end
    arr = L(agent, all_opps);
    opponents = find(arr~=0);
end