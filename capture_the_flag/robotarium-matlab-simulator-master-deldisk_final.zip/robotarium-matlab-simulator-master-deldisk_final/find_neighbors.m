function[neighbors] = find_neighbors(poses, delta, agent)
    N = size(poses, 2);
    L = updateGraph(poses, delta);
    if(agent <= N/2)
        all_neighbors = [1:N/2];
    else
        all_neighbors = [(N/2)+1:N];
    end
    arr = L(agent, all_neighbors);
    neighbors = arr(arr~=0 & arr~=agent);
end